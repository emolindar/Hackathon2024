namespace DynamicStaffing.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
    public class DataRecords
    {
        public int Id { get; set; }
        public TimeSpan TimeOfDay { get; set; } 
        public DateTime Date { get; set; }
        public string DayOfWeek { get; set; }
        public int NumberOfEmployees { get; set; }
        public int NumberOfCustomers { get; set; }
        public int Satisfaction { get; set; } 
        public decimal Profits { get; set; } 
    }

}
