using DynamicStaffing.Models;
using DynamicStaffing.Data;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using CsvHelper;
using Microsoft.AspNetCore.Http;
using System.Globalization;
using CsvHelper.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace DynamicStaffing.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context, ILogger<HomeController> logger)
        {
            _context = context;
            _logger = logger;
        }

        public IActionResult Index()
        {
            ViewBag.Message = "Welcome!";
            return View();
        }

        public IActionResult GetStarted()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public async Task<IActionResult> UploadCsv(IFormFile fileUpload)
        {
            if (fileUpload == null || fileUpload.Length <= 0)
            {
                _logger.LogError("File upload failed: file is null or empty.");
                return View("Error"); // Or return an appropriate response
            }

            try
            {
                using (var stream = fileUpload.OpenReadStream())
                using (var reader = new StreamReader(stream))
                using (var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture) { HasHeaderRecord = true }))
                {
                    var records = csv.GetRecords<DataRecords>().ToList();

                    if (records.Any())
                    {
                        _context.AddRange(records);
                        await _context.SaveChangesAsync();
                    }
                }

                return RedirectToAction("Success"); // Adjust based on your actual success action/view
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error uploading CSV file.");
                return View("Error");
            }
        }
    }
}
